// Single thread application with SIMD extensions

#include <Windows.h>
#include <intrin.h>
// Include required header files
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <tchar.h>
#include <strsafe.h>


#define NTIMES            200   // Number of repetitions to get suitable times
#define SIZE      (1024*1024)   // Number of elements in the array
#define NUM_THREADS		4

int numeroDeIteracionesHilo;

typedef struct op1Arguments {
	double* vector;
	int i;
} ARGUMENTS1, *PARGUMENTS1;

typedef struct op2Arguments {
	double* vector;
	double* max;
	int i;
} ARGUMENTS2, *PARGUMENTS2;

typedef struct op3Arguments {
	double* origen1;
	double* origen2;
	double escalar;
	double* destino;
	int i;
} ARGUMENTS3, *PARGUMENTS3;

void inicializarVector(double* vector) {
	srand(time(NULL));
	for (int i = 0; i < SIZE; i++)
		vector[i] = ((double)(rand() % 2001)) / 1000 - 1;
}

DWORD WINAPI op1(LPVOID param) {
	double* vector = ((PARGUMENTS1)param)->vector;
	int start = ((PARGUMENTS1)param)->i;

	__m128d tmpSqrt;
	for (int i = start; i < start + numeroDeIteracionesHilo; i++) {
		tmpSqrt = _mm_sqrt_pd(*(__m128d*)&vector[i * 2]);
		(*(__m128d *) &vector[i * 2]) = tmpSqrt;
	}
	return 0;
}

DWORD WINAPI op2(LPVOID param) {
	double* vector = ((PARGUMENTS2)param)->vector;
	int start = ((PARGUMENTS2)param)->i;

	__m128d mayores = *(__m128d*)&vector[start];

	for (int i = start + 1; i < start + numeroDeIteracionesHilo; i++)
		mayores = _mm_max_pd(mayores, *(__m128d*)&vector[i * 2]);

	double*result = (double*)&mayores;
	return max((*(double*)&mayores), ((*(double*)&mayores) + 1));
}

DWORD WINAPI op3(LPVOID param) {
	double* origen1 = ((PARGUMENTS3)param)->origen1;
	double* origen2 = ((PARGUMENTS3)param)->origen2;
	double escalar = ((PARGUMENTS3)param)->escalar;
	double* destino = ((PARGUMENTS3)param)->destino;
	int start = ((PARGUMENTS3)param)->i;

	__m128d tmpMult, tmpAnd;
	__m128d escalares = _mm_set_pd(escalar, escalar);
	for (int i = start; i < start + numeroDeIteracionesHilo; i++) {
		tmpMult = _mm_mul_pd(*(__m128d*)&origen1[i * 2], escalares);
		tmpAnd = _mm_and_pd(tmpMult, *(__m128d *)&origen2[i * 2]);
		(*(__m128d *) &destino[i * 2]) = tmpAnd;
	}

	for (int i = start; i < start + numeroDeIteracionesHilo; i++) {
		tmpMult = _mm_mul_pd(*(__m128d*) &origen1[i * 2], escalares);
		tmpAnd = _mm_and_pd(tmpMult, *(__m128d *)&origen2[i * 2]);
		(*(__m128d *) &destino[i * 2]) = tmpAnd;
	}

	return 0;
}


int main() {
	numeroDeIteracionesHilo = SIZE / (4*2);
	HANDLE hThreadArray[4];
	PARGUMENTS1	pArguments1[4];
	PARGUMENTS2	pArguments2[4];
	double* maximos = (double *)malloc(NUM_THREADS * sizeof(double));;
	PARGUMENTS3	pArguments3[4];

	LARGE_INTEGER frequency, tStart, tEnd;
	double dElapsedTimeS = 0;

	double* origen1 = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));
	double* origen2 = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));
	double* origen3 = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));

	inicializarVector(origen1);
	inicializarVector(origen2);
	inicializarVector(origen3);

	double* destino = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));

	// Get clock frequency in Hz
	QueryPerformanceFrequency(&frequency);

	// Get initial clock count
	QueryPerformanceCounter(&tStart);

	for (int times = 0; times < NTIMES; times++) {

		for (int i = 0; i < NUM_THREADS; i++) {
			
			pArguments1[i] = (PARGUMENTS1)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(ARGUMENTS1));
			if (pArguments1[i] == NULL) {
				ExitProcess(2);
			}
			pArguments1[i]->vector = origen1;
			pArguments1[i]->i = i * numeroDeIteracionesHilo;
			hThreadArray[i] = CreateThread(NULL, 0, op1, pArguments1[i], 0, NULL);

			if (hThreadArray[i] != NULL) {
				printf("Thread %d creado\n", i);
			}
			else {
				fprintf(stderr, "ERROR. Thread: %d\n", i);
				return E_FAIL;
			}
		}

		for (int i = 0; i < NUM_THREADS; i++) {
			WaitForSingleObject(hThreadArray[i], INFINITE);
		}

		for (int i = 0; i < NUM_THREADS; i++) {
			pArguments2[i] = (PARGUMENTS2)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(ARGUMENTS2));

			if (pArguments2[i] == NULL) {
				ExitProcess(2);
			}

			pArguments2[i]->vector = origen1;
			pArguments2[i]->i = i * numeroDeIteracionesHilo;
			hThreadArray[i] = CreateThread(NULL, 0, op2, pArguments2[i], 0, NULL);

			if (hThreadArray[i] != NULL) {
				printf("Thread %d creado\n", i);
			}
			else {
				fprintf(stderr, "ERROR. Thread: %d\n", i);
				return E_FAIL;
			}
		}

		double maximo = -1;
		for (int i = 0; i < NUM_THREADS; i++) {
			WaitForSingleObject(hThreadArray[i], INFINITE);
			if (maximos[i] > maximo)
				maximo = maximos[i];
		}


		for (int i = 0; i < NUM_THREADS; i++) {
			pArguments3[i] = (PARGUMENTS3)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(ARGUMENTS3));
			if (pArguments3[i] == NULL) {
				ExitProcess(2);
			}
			pArguments3[i]->origen1 = origen1;
			pArguments3[i]->origen2 = origen3;
			pArguments3[i]->escalar = maximo;
			pArguments3[i]->destino = destino;
			pArguments3[i]->i = i * numeroDeIteracionesHilo;

			hThreadArray[i] = CreateThread(NULL, 0, op3, pArguments3[i], 0, NULL);

			if (hThreadArray[i] != NULL) {
				printf("Thread %d creado\n", i);
			}
			else {
				fprintf(stderr, "ERROR. Thread: %d\n", i);
				return E_FAIL;
			}
		}

		for (int i = 0; i < NUM_THREADS; i++)
			WaitForSingleObject(hThreadArray[i], INFINITE);

	}

	// Get final clock count
	QueryPerformanceCounter(&tEnd);

	// Compute the elapsed time in seconds
	dElapsedTimeS = dElapsedTimeS + ((tEnd.QuadPart - tStart.QuadPart) / (double)frequency.QuadPart);

	// Liberar memoria
	_aligned_free(origen1);
	_aligned_free(origen2);
	_aligned_free(origen3);
	_aligned_free(destino);
	free(maximos);
	// Print the mean elapsed time
	printf("Mean elapsed time in seconds: %f\n", dElapsedTimeS);
}