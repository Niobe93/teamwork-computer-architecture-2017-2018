// Single thread application

#include <Windows.h>
// Include required header files
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <tchar.h>
#include <strsafe.h>
#include <math.h>

#define NTIMES			200				// Number of repetitions to get suitable times
#define SIZE			(1024*1024)		// Number of elements in the array
#define NUM_THREADS		4

int numeroDeIteracionesHilo;


typedef struct op1Arguments {
	double* vector;
	int i;
} ARGUMENTS1, *PARGUMENTS1;

typedef struct op2Arguments {
	double* vector;
	double* max;
	int i;
} ARGUMENTS2, *PARGUMENTS2;

typedef struct op3Arguments {
	double* origen1;
	double* origen2;
	double escalar;
	double* destino;
	int i;
} ARGUMENTS3, *PARGUMENTS3;


void inicializarVector(double* vector) {
	srand(time(NULL));
	for (int i = 0; i < SIZE; i++)
		vector[i] = ((double)(rand() % 2001)) / 1000 - 1;
}

/*double sqrt(double m)
{
	double i = 0;
	double x1, x2;
	while ((i*i) <= m)
		i = i + 0.1;

	x1 = i;
	for (int j = 0; j<10; j++)
	{
		x2 = m;
		x2 = x2 / x1;
		x2 = x2 + x1;
		x2 = x2 / 2;
		x1 = x2;
	}

	return x2;
}*/

DWORD WINAPI op1(LPVOID param) {
	double* vector = ((PARGUMENTS1)param)->vector;
	int start = ((PARGUMENTS1)param)->i;

	for (int i = start; i < start + numeroDeIteracionesHilo; i++) {
		vector[i] = sqrt(vector[i]);
	}

	return 0;
}

DWORD WINAPI op2(LPVOID param) {
	double* vector = ((PARGUMENTS2)param)->vector;
	int start = ((PARGUMENTS2)param)->i;
	double mayor = vector[start];

	for (int i = start + 1; i < start + numeroDeIteracionesHilo; i++) {
		if (vector[i] > mayor)
			mayor = vector[i];

	}
	*(((PARGUMENTS2)param)->vector) = mayor;
	return 0;
}

DWORD WINAPI op3(LPVOID param) {
	double* origen1 = ((PARGUMENTS3)param)->origen1;
	double* origen2 = ((PARGUMENTS3)param)->origen2;
	double escalar = ((PARGUMENTS3)param)->escalar;
	double* destino = ((PARGUMENTS3)param)->destino;

	long long int mascara;

	int start = ((PARGUMENTS3)param)->i;

	for (int i = start; i < start + numeroDeIteracionesHilo; i++) {
		origen1[i] = origen1[i] * escalar;
		mascara = *(long long int*)&origen1[i] & *(long long int*)&origen2[i];
		destino[i] = *(double*)&mascara;
	}

	return 0;
}

int main() {

	/*SYSTEM_INFO sysInfo;
	GetSystemInfo(&sysInfo);
	const int N_HILOS = sysInfo.dwNumberOfProcessors;*/
	numeroDeIteracionesHilo = SIZE / NUM_THREADS;
	HANDLE hThreadArray[NUM_THREADS];
	PARGUMENTS1	pArguments1[NUM_THREADS];
	PARGUMENTS2	pArguments2[NUM_THREADS];
	double* maximos = (double *)malloc(NUM_THREADS * sizeof(double));;
	PARGUMENTS3	pArguments3[NUM_THREADS];

	LARGE_INTEGER frequency, tStart, tEnd;
	double dElapsedTimeS = 0;

	double* origen1 = (double *)malloc(SIZE * sizeof(double));
	double* origen2 = (double *)malloc(SIZE * sizeof(double));
	double* origen3 = (double *)malloc(SIZE * sizeof(double));

	inicializarVector(origen1);
	inicializarVector(origen2);
	inicializarVector(origen3);

	double* destino = (double *)malloc(SIZE * sizeof(double));

	for (int i = 0; i < NUM_THREADS; i++) {
		pArguments1[i] = (PARGUMENTS1)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(ARGUMENTS1));
		if (pArguments1[i] == NULL)
			ExitProcess(2);
		pArguments1[i]->vector = origen1;
		pArguments1[i]->i = i * numeroDeIteracionesHilo;

		pArguments2[i] = (PARGUMENTS2)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(ARGUMENTS2));
		if (pArguments2[i] == NULL)
			ExitProcess(2);
		pArguments2[i]->vector = origen1;
		pArguments2[i]->max = &maximos[i];
		pArguments2[i]->i = i * numeroDeIteracionesHilo;

		pArguments3[i] = (PARGUMENTS3)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(ARGUMENTS3));
		if (pArguments3[i] == NULL)
			ExitProcess(2);
		pArguments3[i]->origen1 = origen1;
		pArguments3[i]->origen2 = origen3;
		pArguments3[i]->destino = destino;
		pArguments3[i]->i = i * numeroDeIteracionesHilo;
	}


	// Get clock frequency in Hz
	QueryPerformanceFrequency(&frequency);

	// Get initial clock count
	QueryPerformanceCounter(&tStart);

	for (int times = 0; times < NTIMES; times++) {
		for (int i = 0; i < NUM_THREADS; i++) {
			hThreadArray[i] = CreateThread(NULL, 0, op1, pArguments1[i], 0, NULL);

			if (hThreadArray[i] != NULL) {
				printf("Thread %d creado\n", i);
			}
			else {
				fprintf(stderr, "ERROR. Thread: %d\n", i);
				return E_FAIL;
			}
		}

		for (int i = 0; i < NUM_THREADS; i++) {
			WaitForSingleObject(hThreadArray[i], INFINITE);
		}

		for (int i = 0; i < NUM_THREADS; i++) {
			hThreadArray[i] = CreateThread(NULL, 0, op2, pArguments2[i], 0, NULL);

			if (hThreadArray[i] != NULL) {
				printf("Thread %d creado\n", i);
			}
			else {
				fprintf(stderr, "ERROR. Thread: %d\n", i);
				return E_FAIL;
			}
		}
		double maximo = -1;
		for (int i = 0; i < NUM_THREADS; i++) {
			WaitForSingleObject(hThreadArray[i], INFINITE);
			if (maximos[i] > maximo)
				maximo = maximos[i];
		}

		for (int i = 0; i < NUM_THREADS; i++) {
			pArguments3[i]->escalar = maximo;
			hThreadArray[i] = CreateThread(NULL, 0, op3, pArguments3[i], 0, NULL);

			if (hThreadArray[i] != NULL) {
				printf("Thread %d creado\n", i);
			}
			else {
				fprintf(stderr, "ERROR. Thread: %d\n", i);
				return E_FAIL;
			}
		}

		for (int i = 0; i < NUM_THREADS; i++)
			WaitForSingleObject(hThreadArray[i], INFINITE);
	}
	// Get final clock count
	QueryPerformanceCounter(&tEnd);

	// Compute the elapsed time in seconds
	dElapsedTimeS = dElapsedTimeS + ((tEnd.QuadPart - tStart.QuadPart) / (double)frequency.QuadPart);

	// Liberar memoria
	free(origen1);
	free(origen2);
	free(origen3);
	free(destino);
	free(maximos);
	// Print the mean elapsed time
	printf("Mean elapsed time in seconds: %f\n", dElapsedTimeS);
}