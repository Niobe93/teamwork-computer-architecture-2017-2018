// Single thread application with SIMD extensions

#include <Windows.h>
#include <intrin.h>
// Include required header files
#include <stdio.h>
#include <time.h>

#define NTIMES            200   // Number of repetitions to get suitable times
#define SIZE      (1024*1024)   // Number of elements in the array

void inicializarVector(double* vector) {
	srand(time(NULL));
	for (int i = 0; i < SIZE; i++)
		vector[i] = ((double)(rand() % 2001)) / 1000 - 1;
}

void op1(double* vector) {
	__m128d tmpSqrt;
	for (int i = 0; i < SIZE / 2; i++) {
		tmpSqrt = _mm_sqrt_pd(*(__m128d*)&vector[i * 2]);
		(*(__m128d *) &vector[i * 2]) = tmpSqrt;
	}
}

double op2(double* vector) {
	__m128d mayores = *(__m128d*)vector;;

	for (int i = 1; i < SIZE / 2; i++)
		mayores = _mm_max_pd(mayores, *(__m128d*)&vector[i * 2]);

	double*result = (double*)&mayores;
	return max((*(double*)&mayores), ((*(double*)&mayores) + 1));
}

void op3(double* origen1, double* origen2, double escalar, double* destino) {
	__m128d tmpMult, tmpAnd;
	double* escalares = (double *)_aligned_malloc(2 * sizeof(double), sizeof(__m128d));
	for (int i = 0; i < 2; i++)
		escalares[i] = escalar;

	for (int i = 0; i < SIZE / 2; i++) {
		tmpMult = _mm_mul_pd(*(__m128d*) &origen1[i * 2], *(__m128d*)escalares);
		tmpAnd = _mm_and_pd(tmpMult, *(__m128d *)&origen2[i * 2]);
		(*(__m128d *) &destino[i * 2]) = tmpAnd;
	}
}

int main() {
	LARGE_INTEGER frequency, tStart, tEnd;
	double dElapsedTimeS = 0;

	double* origen1 = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));
	double* origen2 = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));
	double* origen3 = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));
	inicializarVector(origen1);
	inicializarVector(origen2);
	inicializarVector(origen3);

	double* destino = (double *)_aligned_malloc(SIZE * sizeof(double), sizeof(__m128d));

	// Get clock frequency in Hz
	QueryPerformanceFrequency(&frequency);

	// Get initial clock count
	QueryPerformanceCounter(&tStart);

	for (int i = 0; i < NTIMES; i++) {
		op1(origen1);

		op3(origen1, origen3, op2(origen2), destino);
	}

	// Get final clock count
	QueryPerformanceCounter(&tEnd);

	// Compute the elapsed time in seconds
	dElapsedTimeS = dElapsedTimeS + ((tEnd.QuadPart - tStart.QuadPart) / (double)frequency.QuadPart);

	// Liberar memoria
	_aligned_free(origen1);
	_aligned_free(origen2);
	_aligned_free(origen3);
	_aligned_free(destino);
	// Print the mean elapsed time
	printf("Mean elapsed time in seconds: %f\n", dElapsedTimeS);
}