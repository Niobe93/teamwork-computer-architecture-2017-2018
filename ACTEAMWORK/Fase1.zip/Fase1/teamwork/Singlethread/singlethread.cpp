// S�ingle thread application

#include <Windows.h>
// Include required header files
#include <stdio.h>
#include <time.h>

#define NTIMES			200				// Number of repetitions to get suitable times
#define SIZE			(1024*1024)		// Number of elements in the array

void inicializarVector(double* vector) {
	srand(time(NULL));
	for (int i = 0; i < SIZE; i++)
		vector[i] = ((double)(rand() % 2001)) / 1000 - 1;
}

double sqrt(double m)
{
	double i = 0;
	double x1, x2;
	while ((i*i) <= m)
		i = i + 0.1;

	x1 = i;
	for (int j = 0; j<10; j++)
	{
		x2 = m;
		x2 = x2 / x1;
		x2 = x2 + x1;
		x2 = x2 / 2;
		x1 = x2;
	}

	return x2;
}

void op1(double* vector) {
	for (int i = 0; i < SIZE; i++) {
		vector[i] = sqrt(vector[i]);
	}
}

double op2(double* vector) {
	double mayor = vector[0];

	for (int i = 1; i < SIZE; i++) {
		if (vector[i] > mayor)
			mayor = vector[i];

	}

	return mayor;
}

void op3(double* origen1, double* origen2, double escalar, double* destino) {
	long long int mascara;

	for (int i = 0; i < SIZE; i++) {
		origen1[i] = origen1[i] * escalar;
		mascara = *(long long int*)&origen1[i] & *(long long int*)&origen2[i];
		destino[i] = *(double*)&mascara;
	}
}

int main() {
	LARGE_INTEGER frequency, tStart, tEnd;
	double dElapsedTimeS = 0;

	double* origen1 = (double *)malloc(SIZE * sizeof(double));
	double* origen2 = (double *)malloc(SIZE * sizeof(double));
	double* origen3 = (double *)malloc(SIZE * sizeof(double));
	inicializarVector(origen1);
	inicializarVector(origen2);
	inicializarVector(origen3);

	double* destino = (double *)malloc(SIZE * sizeof(double));

	// Get clock frequency in Hz
	QueryPerformanceFrequency(&frequency);

	// Get initial clock count
	QueryPerformanceCounter(&tStart);

	for (int i = 0; i < NTIMES; i++) {
		op1(origen1);

		op3(origen1, origen3, op2(origen2), destino);
	}

	// Get final clock count
	QueryPerformanceCounter(&tEnd);

	// Compute the elapsed time in seconds
	dElapsedTimeS = dElapsedTimeS + ((tEnd.QuadPart - tStart.QuadPart) / (double)frequency.QuadPart);

	// Liberar memoria
	free(origen1);
	free(origen2);
	free(origen3);
	free(destino);
	// Print the mean elapsed time
	printf("Mean elapsed time in seconds: %f\n", dElapsedTimeS);
}